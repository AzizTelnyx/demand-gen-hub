# Telnyx Demand Gen Strategy Reference

*Moved from USER.md — 2026-02-17*
*Read on demand, not auto-loaded*

---

## Strategic Goals

1. **Scale enterprise pipeline** — shift from SMB-heavy to higher-value enterprise
2. **Improve lead quality over volume** — leads that convert to SQOs and revenue
3. **Build predictable demand engine** — repeatable programs with clear ROI
4. **Enable Sales with high-intent accounts** — intent data + ABM
5. **Prove marketing's revenue contribution** — pipeline influence, not just MQLs
6. **Globalize demand programs** — localized campaigns across regions

---

## Strategic Challenges

- Balancing self-serve developer motion with high-touch enterprise sales
- Competing against larger, better-funded competitors (Twilio)
- Educating market on Telnyx's infrastructure advantages
- Aligning Marketing, Sales, RevOps on funnel definitions
- Building attribution for long, multi-touch enterprise cycles
- Scaling without scaling headcount → automation and AI

---

## Key Metrics

- Inbound leads
- SQOs (Sales Qualified Opportunities)
- Pipeline generated and influenced
- Pipeline velocity
- Customer acquisition cost (CAC)
- Channel and campaign ROI
- Website conversion rates

---

## Success Definitions

- **Leading:** Inbound volume, lead→MQL, MQL→SQO conversion, cost per SQO
- **Lagging:** Pipeline created/influenced, closed-won revenue, CAC payback
- **Efficiency:** CAC by channel, ROI by campaign, budget pacing
- **Quality:** SQO acceptance rate, avg deal size, sales feedback

---

## Aziz's Responsibilities

- Own global demand generation strategy (AMER, EU, APAC, MENA)
- Drive inbound demand and SQO creation with Sales and RevOps
- Execute campaigns across paid, ABM, lifecycle, and web
- Own marketing budget, pacing, and ROI accountability
- Lead paid acquisition (Google, LinkedIn, StackAdapt, Reddit)
- Coordinate with Product Marketing on positioning/launches
- Build enterprise ABM programs
- Establish funnel analytics and attribution reporting

---

## Cross-Functional Dynamics

- **Sales:** Primary customer — demand gen feeds them qualified opportunities
- **RevOps:** Funnel definitions, Salesforce, attribution, reporting
- **Product Marketing:** Messaging, positioning, competitive intel, launches
- **Content:** Campaign assets, landing pages, nurture sequences
- **Finance:** Budget planning, spend forecasting, ROI reporting
